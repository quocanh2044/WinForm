﻿using System.Data;
using System.Text.RegularExpressions;

namespace QuanLy
{
    public partial class Form1 : Form
    {
        DataTable studentTable = new DataTable();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Cấu hình bảng dữ liệu
            studentTable.Columns.Add("MSSV");
            studentTable.Columns.Add("Họ Tên");
            studentTable.Columns.Add("Lớp");
            studentTable.Columns.Add("Ngày Sinh");
            studentTable.Columns.Add("Giới Tính");
            studentTable.Columns.Add("Gmail");
            studentTable.Columns.Add("SĐT");
            studentTable.Columns.Add("Địa chỉ");

            dgvStudents.DataSource = studentTable;
            dgvStudents.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void btnAddStudent_Click(object sender, EventArgs e)
        {
            if (!ValidateData()) return;

            if (studentTable.AsEnumerable().Any(r => r.Field<string>("MSSV") == txtStudentId.Text))
            {
                MessageBox.Show("MSSV này đã tồn tại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            studentTable.Rows.Add(txtStudentId.Text, txtStudentName.Text, txtClass.Text,
                                  txtBirthday.Text, txtGender.Text, txtGmail.Text,
                                  txtPhone.Text, txtAddress.Text);

            ClearForm();
            MessageBox.Show("Thêm sinh viên mới thành công!", "Thông báo");
        }

        private void btnUpdateStudent_Click(object sender, EventArgs e)
        {
            if (dgvStudents.CurrentRow == null) return;

            string idToFind = txtStudentId.Text;
            DataRow row = studentTable.AsEnumerable().FirstOrDefault(r => r.Field<string>("MSSV") == idToFind);

            if (row != null)
            {
                row["Lớp"] = txtClass.Text;
                row["Ngày Sinh"] = txtBirthday.Text;
                row["Giới Tính"] = txtGender.Text;
                row["Gmail"] = txtGmail.Text;
                row["SĐT"] = txtPhone.Text;
                row["Địa chỉ"] = txtAddress.Text;

                MessageBox.Show("Cập nhật thành công (Giữ nguyên MSSV & Tên).");
                ClearForm();
            }
        }

        private void btnDeleteStudent_Click(object sender, EventArgs e)
        {
            if (dgvStudents.CurrentRow != null)
            {
                var res = MessageBox.Show("Xác nhận xóa sinh viên đang chọn?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (res == DialogResult.Yes)
                {
                    dgvStudents.Rows.RemoveAt(dgvStudents.CurrentRow.Index);
                    ClearForm();
                }
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            var res = MessageBox.Show("Bạn có muốn thoát chương trình?", "Thoát", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.Yes) Application.Exit();
        }

        private void dgvStudents_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvStudents.Rows[e.RowIndex];
                txtStudentId.Text = row.Cells["MSSV"].Value.ToString();
                txtStudentName.Text = row.Cells["Họ Tên"].Value.ToString();
                txtClass.Text = row.Cells["Lớp"].Value.ToString();
                txtBirthday.Text = row.Cells["Ngày Sinh"].Value.ToString();
                txtGender.Text = row.Cells["Giới Tính"].Value.ToString();
                txtGmail.Text = row.Cells["Gmail"].Value.ToString();
                txtPhone.Text = row.Cells["SĐT"].Value.ToString();
                txtAddress.Text = row.Cells["Địa chỉ"].Value.ToString();

                // Khóa các trường định danh
                txtStudentId.ReadOnly = true;
                txtStudentName.ReadOnly = true;
                txtStudentId.BackColor = Color.LightGray;
                txtStudentName.BackColor = Color.LightGray;
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            DataView dv = studentTable.DefaultView;
            dv.RowFilter = string.Format("[Họ Tên] LIKE '%{0}%' OR MSSV LIKE '%{0}%'", txtSearch.Text);
        }

        private void ClearForm()
        {
            foreach (Control c in groupBoxInput.Controls) if (c is TextBox) c.Text = "";
            txtAddress.Text = "";
            txtStudentId.ReadOnly = false;
            txtStudentName.ReadOnly = false;
            txtStudentId.BackColor = Color.White;
            txtStudentName.BackColor = Color.White;
            txtStudentId.Focus();
        }

        private bool ValidateData()
        {
            if (string.IsNullOrWhiteSpace(txtStudentId.Text) || string.IsNullOrWhiteSpace(txtStudentName.Text))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ MSSV và Họ Tên!");
                return false;
            }
            return true;
        }
    }
}