﻿namespace QuanLy
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            txtStudentId = new TextBox();
            txtStudentName = new TextBox();
            txtClass = new TextBox();
            txtGmail = new TextBox();
            txtPhone = new TextBox();
            txtAddress = new TextBox();
            txtSearch = new TextBox();
            txtBirthday = new TextBox();
            txtGender = new TextBox();
            btnAddStudent = new Button();
            btnUpdateStudent = new Button();
            btnDeleteStudent = new Button();
            btnExit = new Button();
            dgvStudents = new DataGridView();
            label1 = new Label(); label2 = new Label(); label3 = new Label();
            label4 = new Label(); label5 = new Label(); label6 = new Label();
            label7 = new Label(); label8 = new Label(); lblSearch = new Label();
            groupBoxInput = new GroupBox();

            ((System.ComponentModel.ISupportInitialize)dgvStudents).BeginInit();
            groupBoxInput.SuspendLayout();
            SuspendLayout();

            // --- GROUPBOX: Thông tin chi tiết ---
            groupBoxInput.Text = "THÔNG TIN SINH VIÊN";
            groupBoxInput.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            groupBoxInput.Location = new Point(20, 15);
            groupBoxInput.Size = new Size(625, 200);

            int col1L = 20, col1I = 100, w1 = 180;
            int col2L = 320, col2I = 415, w2 = 190;

            // Cột 1
            label1.Text = "MSSV:"; label1.Location = new Point(col1L, 35); label1.AutoSize = true;
            txtStudentId.Location = new Point(col1I, 32); txtStudentId.Size = new Size(w1, 23);

            label2.Text = "Họ Tên:"; label2.Location = new Point(col1L, 75); label2.AutoSize = true;
            txtStudentName.Location = new Point(col1I, 72); txtStudentName.Size = new Size(w1, 23);

            label3.Text = "Lớp:"; label3.Location = new Point(col1L, 115); label3.AutoSize = true;
            txtClass.Location = new Point(col1I, 112); txtClass.Size = new Size(w1, 23);

            label8.Text = "Giới tính:"; label8.Location = new Point(col1L, 155); label8.AutoSize = true;
            txtGender.Location = new Point(col1I, 152); txtGender.Size = new Size(w1, 23);

            // Cột 2
            lblSearch.Text = "Tìm nhanh:"; lblSearch.Location = new Point(col2L, 35); lblSearch.AutoSize = true;
            txtSearch.Location = new Point(col2I, 32); txtSearch.Size = new Size(w2, 23);
            txtSearch.PlaceholderText = "Nhập MSSV/Tên...";
            txtSearch.TextChanged += txtSearch_TextChanged;

            label4.Text = "Gmail:"; label4.Location = new Point(col2L, 75); label4.AutoSize = true;
            txtGmail.Location = new Point(col2I, 72); txtGmail.Size = new Size(w2, 23);

            label5.Text = "SĐT:"; label5.Location = new Point(col2L, 115); label5.AutoSize = true;
            txtPhone.Location = new Point(col2I, 112); txtPhone.Size = new Size(w2, 23);

            label7.Text = "Ngày sinh:"; label7.Location = new Point(col2L, 155); label7.AutoSize = true;
            txtBirthday.Location = new Point(col2I, 152); txtBirthday.Size = new Size(w2, 23);
            txtBirthday.PlaceholderText = "dd/mm/yyyy";

            // Địa chỉ (Nằm dưới GroupBox)
            label6.Text = "Địa chỉ:"; label6.Location = new Point(25, 233); label6.AutoSize = true;
            txtAddress.Location = new Point(120, 230); txtAddress.Size = new Size(525, 23);

            // --- HỆ THỐNG NÚT BẤM ---
            int btnY = 270;
            btnAddStudent.Text = "Thêm mới"; btnAddStudent.Location = new Point(120, btnY);
            btnAddStudent.Size = new Size(100, 35); btnAddStudent.BackColor = Color.LightGreen;
            btnAddStudent.FlatStyle = FlatStyle.Flat; btnAddStudent.Click += btnAddStudent_Click;

            btnUpdateStudent.Text = "Cập nhật"; btnUpdateStudent.Location = new Point(240, btnY);
            btnUpdateStudent.Size = new Size(100, 35); btnUpdateStudent.BackColor = Color.LightYellow;
            btnUpdateStudent.FlatStyle = FlatStyle.Flat; btnUpdateStudent.Click += btnUpdateStudent_Click;

            btnDeleteStudent.Text = "Xóa"; btnDeleteStudent.Location = new Point(360, btnY);
            btnDeleteStudent.Size = new Size(100, 35); btnDeleteStudent.BackColor = Color.MistyRose;
            btnDeleteStudent.FlatStyle = FlatStyle.Flat; btnDeleteStudent.Click += btnDeleteStudent_Click;

            btnExit.Text = "Thoát"; btnExit.Location = new Point(480, btnY);
            btnExit.Size = new Size(100, 35); btnExit.BackColor = Color.Gainsboro;
            btnExit.FlatStyle = FlatStyle.Flat; btnExit.Click += btnExit_Click;

            // --- DATAGRIDVIEW ---
            dgvStudents.Location = new Point(20, 325);
            dgvStudents.Size = new Size(625, 200);
            dgvStudents.BackgroundColor = Color.White;
            dgvStudents.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvStudents.ReadOnly = true;
            dgvStudents.CellClick += dgvStudents_CellClick;

            // --- FORM CHÍNH ---
            ClientSize = new Size(665, 550);
            groupBoxInput.Controls.AddRange(new Control[] { label1, txtStudentId, label2, txtStudentName, label3, txtClass, label8, txtGender, lblSearch, txtSearch, label4, txtGmail, label5, txtPhone, label7, txtBirthday });
            Controls.AddRange(new Control[] { groupBoxInput, label6, txtAddress, btnAddStudent, btnUpdateStudent, btnDeleteStudent, btnExit, dgvStudents });

            this.Font = new Font("Segoe UI", 9F);
            this.BackColor = Color.FromArgb(240, 240, 240);
            Text = "Quản Lý Sinh Viên v3.0 - Professional";
            StartPosition = FormStartPosition.CenterScreen;
            Load += Form1_Load;

            ((System.ComponentModel.ISupportInitialize)dgvStudents).EndInit();
            groupBoxInput.ResumeLayout(false);
            groupBoxInput.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        private TextBox txtStudentId, txtStudentName, txtClass, txtGmail, txtPhone, txtAddress, txtSearch, txtBirthday, txtGender;
        private Button btnAddStudent, btnUpdateStudent, btnDeleteStudent, btnExit;
        private DataGridView dgvStudents;
        private Label label1, label2, label3, label4, label5, label6, label7, label8, lblSearch;
        private GroupBox groupBoxInput;
    }
}