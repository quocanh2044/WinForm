﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Article20
{
    public class Employee
    {
        public string Ma { get; set; }
        public string Ten { get; set; }
        public int Tuoi { get; set; }
        public bool Nam { get; set; }
    }

}
