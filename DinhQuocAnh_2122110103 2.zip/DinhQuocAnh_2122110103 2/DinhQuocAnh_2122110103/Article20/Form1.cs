using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Article20;

namespace Article20
{
    public partial class Form1 : Form
    {
        List<Employee> list = new List<Employee>();

        public Form1()
        {
            InitializeComponent();

            // D? li?u m?u
            list.Add(new Employee { Ma = "53418", Ten = "Tr?n Ti?n", Tuoi = 20, Nam = true });
            list.Add(new Employee { Ma = "53416", Ten = "Nguy?n C??ng", Tuoi = 25, Nam = false });
            list.Add(new Employee { Ma = "53417", Ten = "Nguy?n H�o", Tuoi = 23, Nam = true });

            dgvEmployee.DataSource = list;

            dgvEmployee.SelectionChanged += dgvEmployee_SelectionChanged;
        }

        private void dgvEmployee_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvEmployee.CurrentRow == null) return;

            txtMa.Text = dgvEmployee.CurrentRow.Cells[0].Value.ToString();
            txtTen.Text = dgvEmployee.CurrentRow.Cells[1].Value.ToString();
            txtTuoi.Text = dgvEmployee.CurrentRow.Cells[2].Value.ToString();
            chkNam.Checked = (bool)dgvEmployee.CurrentRow.Cells[3].Value;
        }

        private void btThem_Click(object sender, EventArgs e)
        {
            Employee emp = new Employee()
            {
                Ma = txtMa.Text,
                Ten = txtTen.Text,
                Tuoi = int.Parse(txtTuoi.Text),
                Nam = chkNam.Checked
            };

            list.Add(emp);

            dgvEmployee.DataSource = null;
            dgvEmployee.DataSource = list;
        }

        private void btXoa_Click(object sender, EventArgs e)
        {
            if (dgvEmployee.CurrentRow == null) return;

            list.RemoveAt(dgvEmployee.CurrentRow.Index);

            dgvEmployee.DataSource = null;
            dgvEmployee.DataSource = list;
        }

        private void btThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
