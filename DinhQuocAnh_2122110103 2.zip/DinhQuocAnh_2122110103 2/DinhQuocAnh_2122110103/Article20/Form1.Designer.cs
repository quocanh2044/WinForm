﻿namespace Article20
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.dgvEmployee = new System.Windows.Forms.DataGridView();
            this.txtMa = new System.Windows.Forms.TextBox();
            this.txtTen = new System.Windows.Forms.TextBox();
            this.txtTuoi = new System.Windows.Forms.TextBox();
            this.chkNam = new System.Windows.Forms.CheckBox();
            this.btThem = new System.Windows.Forms.Button();
            this.btXoa = new System.Windows.Forms.Button();
            this.btThoat = new System.Windows.Forms.Button();
            this.lblMa = new System.Windows.Forms.Label();
            this.lblTen = new System.Windows.Forms.Label();
            this.lblTuoi = new System.Windows.Forms.Label();

            ((System.ComponentModel.ISupportInitialize)(this.dgvEmployee)).BeginInit();
            this.SuspendLayout();

            // 
            // dgvEmployee
            // 
            this.dgvEmployee.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEmployee.Location = new System.Drawing.Point(20, 20);
            this.dgvEmployee.Name = "dgvEmployee";
            this.dgvEmployee.Size = new System.Drawing.Size(600, 180);
            this.dgvEmployee.TabIndex = 0;

            // 
            // lblMa
            // 
            this.lblMa.AutoSize = true;
            this.lblMa.Location = new System.Drawing.Point(40, 220);
            this.lblMa.Name = "lblMa";
            this.lblMa.Size = new System.Drawing.Size(25, 15);
            this.lblMa.Text = "Mã";

            // 
            // txtMa
            // 
            this.txtMa.Location = new System.Drawing.Point(120, 217);
            this.txtMa.Name = "txtMa";
            this.txtMa.Size = new System.Drawing.Size(150, 23);

            // 
            // lblTen
            // 
            this.lblTen.AutoSize = true;
            this.lblTen.Location = new System.Drawing.Point(40, 255);
            this.lblTen.Name = "lblTen";
            this.lblTen.Size = new System.Drawing.Size(28, 15);
            this.lblTen.Text = "Tên";

            // 
            // txtTen
            // 
            this.txtTen.Location = new System.Drawing.Point(120, 252);
            this.txtTen.Name = "txtTen";
            this.txtTen.Size = new System.Drawing.Size(200, 23);

            // 
            // lblTuoi
            // 
            this.lblTuoi.AutoSize = true;
            this.lblTuoi.Location = new System.Drawing.Point(40, 290);
            this.lblTuoi.Name = "lblTuoi";
            this.lblTuoi.Size = new System.Drawing.Size(31, 15);
            this.lblTuoi.Text = "Tuổi";

            // 
            // txtTuoi
            // 
            this.txtTuoi.Location = new System.Drawing.Point(120, 287);
            this.txtTuoi.Name = "txtTuoi";
            this.txtTuoi.Size = new System.Drawing.Size(80, 23);

            // 
            // chkNam
            // 
            this.chkNam.AutoSize = true;
            this.chkNam.Location = new System.Drawing.Point(120, 320);
            this.chkNam.Name = "chkNam";
            this.chkNam.Size = new System.Drawing.Size(52, 19);
            this.chkNam.Text = "Nam";
            this.chkNam.UseVisualStyleBackColor = true;

            // 
            // btThem
            // 
            this.btThem.Location = new System.Drawing.Point(200, 360);
            this.btThem.Name = "btThem";
            this.btThem.Size = new System.Drawing.Size(90, 30);
            this.btThem.Text = "Thêm";
            this.btThem.UseVisualStyleBackColor = true;
            this.btThem.Click += new System.EventHandler(this.btThem_Click);

            // 
            // btXoa
            // 
            this.btXoa.Location = new System.Drawing.Point(310, 360);
            this.btXoa.Name = "btXoa";
            this.btXoa.Size = new System.Drawing.Size(90, 30);
            this.btXoa.Text = "Xóa";
            this.btXoa.UseVisualStyleBackColor = true;
            this.btXoa.Click += new System.EventHandler(this.btXoa_Click);

            // 
            // btThoat
            // 
            this.btThoat.Location = new System.Drawing.Point(420, 360);
            this.btThoat.Name = "btThoat";
            this.btThoat.Size = new System.Drawing.Size(90, 30);
            this.btThoat.Text = "Thoát";
            this.btThoat.UseVisualStyleBackColor = true;
            this.btThoat.Click += new System.EventHandler(this.btThoat_Click);

            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(650, 420);
            this.Controls.Add(this.dgvEmployee);
            this.Controls.Add(this.lblMa);
            this.Controls.Add(this.txtMa);
            this.Controls.Add(this.lblTen);
            this.Controls.Add(this.txtTen);
            this.Controls.Add(this.lblTuoi);
            this.Controls.Add(this.txtTuoi);
            this.Controls.Add(this.chkNam);
            this.Controls.Add(this.btThem);
            this.Controls.Add(this.btXoa);
            this.Controls.Add(this.btThoat);
            this.Name = "Form1";
            this.Text = "Quản lý nhân viên";

            ((System.ComponentModel.ISupportInitialize)(this.dgvEmployee)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.DataGridView dgvEmployee;
        private System.Windows.Forms.TextBox txtMa;
        private System.Windows.Forms.TextBox txtTen;
        private System.Windows.Forms.TextBox txtTuoi;
        private System.Windows.Forms.CheckBox chkNam;
        private System.Windows.Forms.Button btThem;
        private System.Windows.Forms.Button btXoa;
        private System.Windows.Forms.Button btThoat;
        private System.Windows.Forms.Label lblMa;
        private System.Windows.Forms.Label lblTen;
        private System.Windows.Forms.Label lblTuoi;
    }
}
