﻿namespace Example11
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblDisplay = new System.Windows.Forms.Label();
            this.btStart = new System.Windows.Forms.Button();
            this.btStop = new System.Windows.Forms.Button();
            this.tmStopwatch = new System.Windows.Forms.Timer(this.components);

            this.SuspendLayout();

            // lblDisplay
            this.lblDisplay.AutoSize = true;
            this.lblDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F);
            this.lblDisplay.Location = new System.Drawing.Point(80, 40);
            this.lblDisplay.Name = "lblDisplay";
            this.lblDisplay.Size = new System.Drawing.Size(180, 73);
            this.lblDisplay.Text = "00:00";

            // btStart
            this.btStart.Location = new System.Drawing.Point(60, 150);
            this.btStart.Name = "btStart";
            this.btStart.Size = new System.Drawing.Size(100, 35);
            this.btStart.Text = "Start";
            this.btStart.UseVisualStyleBackColor = true;
            this.btStart.Click += new System.EventHandler(this.btStart_Click);

            // btStop
            this.btStop.Location = new System.Drawing.Point(180, 150);
            this.btStop.Name = "btStop";
            this.btStop.Size = new System.Drawing.Size(100, 35);
            this.btStop.Text = "Stop";
            this.btStop.UseVisualStyleBackColor = true;
            this.btStop.Click += new System.EventHandler(this.btStop_Click);

            // tmStopwatch
            this.tmStopwatch.Interval = 100;
            this.tmStopwatch.Tick += new System.EventHandler(this.tmStopwatch_Tick);

            // Form1
            this.ClientSize = new System.Drawing.Size(350, 230);
            this.Controls.Add(this.lblDisplay);
            this.Controls.Add(this.btStart);
            this.Controls.Add(this.btStop);
            this.Name = "Form1";
            this.Text = "Timer Article";

            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblDisplay;
        private System.Windows.Forms.Button btStart;
        private System.Windows.Forms.Button btStop;
        private System.Windows.Forms.Timer tmStopwatch;
    }
}
