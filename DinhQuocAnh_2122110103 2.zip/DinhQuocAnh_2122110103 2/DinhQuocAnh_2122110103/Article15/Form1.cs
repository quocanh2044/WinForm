﻿using System;
using System.Windows.Forms;

namespace Article15
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            // Định dạng DateTimePicker
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "dd/MM/yyyy";

            // Gán sự kiện đúng control
            dateTimePicker1.ValueChanged += dateTimePicker1_ValueChanged;
            btOK.Click += btOK_Click;
        }

        private void btOK_Click(object sender, EventArgs e)
        {
            this.Text = dateTimePicker1.Value.ToLongDateString();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            this.Text = dateTimePicker1.Value.ToShortDateString();
        }
    }
}
