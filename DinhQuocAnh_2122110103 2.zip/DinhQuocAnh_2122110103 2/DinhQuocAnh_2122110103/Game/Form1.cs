﻿using System;
using System.Drawing;
using System.Media;
using System.Windows.Forms;

namespace Game
{
    public partial class FormGame : Form
    {
        int score = 0;
        int level = 1;
        int eggSpeed = 8;
        int chickenSpeed = 6;
        int basketSpeed = 35;
        Random rand = new Random();

        private SoundPlayer backgroundMusic;
        private SoundPlayer catchSound;
        private SoundPlayer breakSound;

        private TransparentPanel overlayPanel; // Panel mờ khi qua màn

        public FormGame()
        {
            InitializeComponent();
            LoadResources();
            SetupGame();
        }

        private void LoadResources()
        {
            try
            {
                // Hình ảnh
                basket.Image = Properties.Resources.basket;
                egg.Image = Properties.Resources.egg1;
                chicken.Image = Properties.Resources.chicken;
                this.BackgroundImage = Properties.Resources.game;

                // Tạo panel mờ khi qua màn
                overlayPanel = new TransparentPanel();
                overlayPanel.BackColor = Color.Black;
                overlayPanel.Dock = DockStyle.Fill;
                overlayPanel.Visible = false; // Ẩn panel mờ
                this.Controls.Add(overlayPanel);
            }
            catch { }
        }

        private void SetupGame()
        {
            score = 0;
            level = 1;
            eggSpeed = 8;
            chickenSpeed = 6;

            lblScore.Text = $"Điểm: {score} - Màn: {level}";

            try { egg.Image = Properties.Resources.egg1; } catch { }
            egg.Size = new Size(30, 40);

            if (backgroundMusic != null) backgroundMusic.PlayLooping();

            gameTimer.Tick -= GameTimerEvent;
            gameTimer.Tick += GameTimerEvent;
            gameTimer.Start();

            ResetEgg();
        }

        private void GameTimerEvent(object sender, EventArgs e)
        {
            // 1. Di chuyển gà
            chicken.Left += chickenSpeed;
            if (chicken.Left <= 0 || chicken.Left >= this.ClientSize.Width - chicken.Width)
            {
                chickenSpeed = -chickenSpeed;
            }

            // 2. Trứng rơi
            egg.Top += eggSpeed;

            // 3. Hứng trứng
            if (egg.Bounds.IntersectsWith(basket.Bounds))
            {
                if (catchSound != null) catchSound.Play();
                score++;

                // Kiểm tra nếu đạt 5 điểm để lên màn mới
                if (score % 5 == 0)
                {
                    // Tạm dừng game
                    gameTimer.Stop();
                    level++;
                    eggSpeed += 2;      // Tăng tốc độ trứng
                    chickenSpeed += 1;  // Tăng tốc độ gà

                    // Hiển thị màn hình mờ và thông báo
                    ShowLevelUpOverlay();

                    // Reset trứng và tiếp tục game sau 1-2 giây
                    System.Threading.Thread.Sleep(1000);  // Thời gian chờ 1 giây
                    ResetEgg();
                    gameTimer.Start();
                }

                lblScore.Text = $"Điểm: {score} - Màn: {level}";
                ResetEgg();
            }

            // 4. Trứng rơi xuống đất
            if (egg.Bottom >= this.ClientSize.Height - 10)
            {
                gameTimer.Stop();

                if (backgroundMusic != null) backgroundMusic.Stop();
                if (breakSound != null) breakSound.Play();

                try
                {
                    egg.Image = Properties.Resources.egg;
                    egg.Size = new Size(40, 25);
                    egg.Top = this.ClientSize.Height - egg.Height;
                    egg.Refresh();
                }
                catch { egg.BackColor = Color.Red; }

                System.Threading.Thread.Sleep(500);

                DialogResult dr = MessageBox.Show($"Trứng đã bể! Điểm của bạn: {score}\nChơi lại không?", "Kết thúc", MessageBoxButtons.YesNo);
                if (dr == DialogResult.Yes) SetupGame();
                else this.Close();
            }
        }

        private void ShowLevelUpOverlay()
        {
            // Hiển thị panel mờ
            overlayPanel.Visible = true;

            // Hiển thị thông báo "Chúc mừng! Bạn sang màn mới"
            MessageBox.Show($"Chúc mừng! Bạn sang màn {level}", "Màn mới");

            // Ẩn panel mờ sau 1-2 giây
            System.Windows.Forms.Timer overlayTimer = new System.Windows.Forms.Timer(); // Explicitly using Windows Forms Timer
            overlayTimer.Interval = 1000; // 1 giây
            overlayTimer.Tick += (sender, e) =>
            {
                overlayPanel.Visible = false;
                overlayTimer.Stop(); // Dừng timer
            };
            overlayTimer.Start();
        }

        private void ResetEgg()
        {
            egg.Top = chicken.Bottom;
            egg.Left = chicken.Left + (chicken.Width / 2) - (egg.Width / 2);
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Left && basket.Left > 10) basket.Left -= basketSpeed;
            if (keyData == Keys.Right && basket.Left < this.ClientSize.Width - basket.Width - 10) basket.Left += basketSpeed;
            return base.ProcessCmdKey(ref msg, keyData);
        }
    }

    // Subclassing Panel to create a transparent panel
    public class TransparentPanel : Panel
    {
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            // Set alpha transparency (50%)
            e.Graphics.FillRectangle(new SolidBrush(Color.FromArgb(128, Color.Black)), this.ClientRectangle);
        }
    }
}
