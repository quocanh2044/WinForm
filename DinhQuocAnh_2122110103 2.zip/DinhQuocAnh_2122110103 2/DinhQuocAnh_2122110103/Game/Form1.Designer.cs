﻿namespace Game
{
    partial class FormGame
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.basket = new System.Windows.Forms.PictureBox();
            this.egg = new System.Windows.Forms.PictureBox();
            this.chicken = new System.Windows.Forms.PictureBox();
            this.lblScore = new System.Windows.Forms.Label();
            this.gameTimer = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.basket)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.egg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chicken)).BeginInit();
            this.SuspendLayout();

            // basket
            this.basket.BackColor = System.Drawing.Color.Transparent;
            this.basket.Size = new System.Drawing.Size(80, 50);
            this.basket.Location = new System.Drawing.Point(260, 600);
            this.basket.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;

            // egg
            this.egg.BackColor = System.Drawing.Color.Transparent;
            this.egg.Size = new System.Drawing.Size(30, 40);
            this.egg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;

            // chicken
            this.chicken.BackColor = System.Drawing.Color.Transparent;
            this.chicken.Size = new System.Drawing.Size(100, 80);
            this.chicken.Location = new System.Drawing.Point(240, 10);
            this.chicken.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;

            // lblScore
            this.lblScore.AutoSize = true;
            this.lblScore.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblScore.ForeColor = System.Drawing.Color.White;
            this.lblScore.Location = new System.Drawing.Point(12, 9);
            this.lblScore.Text = "Điểm: 0 - Màn: 1";

            // gameTimer
            this.gameTimer.Interval = 20;

            // FormGame
            this.ClientSize = new System.Drawing.Size(584, 661);
            this.Controls.Add(this.lblScore);
            this.Controls.Add(this.egg);
            this.Controls.Add(this.basket);
            this.Controls.Add(this.chicken);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "FormGame";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Game Gà Hứng Trứng Pro";
            ((System.ComponentModel.ISupportInitialize)(this.basket)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.egg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chicken)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.PictureBox basket;
        private System.Windows.Forms.PictureBox egg;
        private System.Windows.Forms.PictureBox chicken;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.Timer gameTimer;
    }
}
