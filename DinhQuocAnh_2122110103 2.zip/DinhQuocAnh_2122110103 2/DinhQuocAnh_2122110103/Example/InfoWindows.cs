﻿namespace Example
{
    public class InfoWindows
    {
        public int Width { get; set; }
        public int Height { get; set; }
    }
}
